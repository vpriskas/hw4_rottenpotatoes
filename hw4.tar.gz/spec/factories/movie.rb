
FactoryGirl.define do
factory :movie do
title 'A Fake Title' # default values
rating 'PG'
director 'Ela'
end
end
